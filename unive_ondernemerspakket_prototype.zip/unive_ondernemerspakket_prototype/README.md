# Univé Zakelijk Ondernemerspakket Funnel 2.0 – prototype

## Starten
Open `index.html` direct in een moderne browser. Er is geen buildstap of server nodig.

## Ingebouwd
- 6 hoofdfases + bedanktpagina
- 5 uiteenlopende demoscenario's
- KVK/mock bedrijfsselectie en known/inferred/confirmed-denkwijze
- conditionele vragen
- eligibility-routing inclusief advisor route
- risk/recommendation engine
- uitlegbaar voorstel
- toevoegen/verwijderen van verzekeringen
- wijzigen dekking en eigen risico met directe prijsfeedback
- meerdere bedrijfsauto-objecten
- sticky pakketsamenvatting (desktop) en compacte mobiele totaalbalk
- aanvraaggegevens, controlepagina en gesimuleerde aanvraag
- afgeschermd demo/debugpaneel voor scenario, stap, eligibility en foutstates
- KVK- en prijsstoringen
- responsive/mobile-first gedrag en zichtbare focus-states

## Belangrijk
Alle bedrijfs-, premie-, acceptatie- en advieslogica is mock/prototype-logica en geen definitief Univé-beleid.
